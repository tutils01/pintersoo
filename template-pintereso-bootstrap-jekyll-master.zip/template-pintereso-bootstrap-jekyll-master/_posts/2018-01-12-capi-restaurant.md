---
title:  "Capi Restaurant"
metadate: "hide"
categories: [ Premium, UI, Graphics, Templates ]
image: "/assets/images/capi.jpg"
visit: "https://crmrkt.com/2QKymR"
---
Capi Restaurant UI Kit is a high quality pack of 40+ social app screens based on iOS 11 which will accelerate your design process and will help develop an outstanding experience.

100% Vector Based, so all screens can be easily resized to fit other iPhone screens. Dimensions 375x812 and 375x667.